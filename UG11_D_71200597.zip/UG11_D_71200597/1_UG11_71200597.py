def tempat():
    
    def tempatMenonton():
        print("1. XXI Empire")
        print("2. XXI Amplaz")
        print("3. XXI JCM")

        pilih = int(input("Masukkan pilihanmu: "))
        if pilih == 1:
            print("")
        elif pilih == 2:
            print("")
        elif pilih == 3:
            print("")
        else:
            print("Pilihan tidak tersedia")
    tempatMenonton()
    def pemilihanFilm():
        print("1. Frozen")
        print("2. Keramat")
        print("3. KKN di Desa Penari")

        pilih = int(input("Pilih film: "))
        if pilih == 1:
            print("")
        elif pilih == 2:
            print("")
        elif pilih == 3:
            print("")
        else:
            print("Pilihan tidak tersedia")
    pemilihanFilm()

    def layarBioskop():
        print("1. Reguler")
        print("2. Dolby almos")
        print("3. Premiere")

        pilih = int(input("Pilih layar: "))
        if pilih == 1:
            print("")
        elif pilih == 2:
            print("")
        elif pilih == 3:
            print("")
        else:
            print("Pilihan tidak tersedia")
    layarBioskop()

    def jamBerapa():
        print("1. 12.35")
        print("2. 14.45")
        print("3. 16.55")
        print("4. 19.05")


        pilih = int(input("Pilih jam: "))
        if pilih == 1:
            print("Oke berhasil, silahkan dinikmati di jam 12.35")
        elif pilih == 2:
            print("Oke berhasil, silahkan dinikmati di jam 14.45")
        elif pilih == 3:
            print("Oke berhasil, silahkan dinikmati di jam 16.55")
        elif pilih == 4:
            print("Oke berhasil, silahkan dinikmati di jam 19.05")
        else:
            print("Pilihan tidak tersedia")
    jamBerapa()


tempat()